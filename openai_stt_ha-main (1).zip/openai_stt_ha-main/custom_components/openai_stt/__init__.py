""" Custom integration for OpenAI Whisper STT API."""
